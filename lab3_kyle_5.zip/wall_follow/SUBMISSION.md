# Lab 3: Wall Following

## YouTube video links
Simulator (individual) : [FILL ME IN](https://youtu.be/gx5rz7Fhpss)

Hardware (group) : [FILL ME IN]()
