# Lab 3: Wall Following

## YouTube video links
Simulator (individual) : [Link](https://youtu.be/gx5rz7Fhpss)

Hardware (group) : [Link](https://www.youtube.com/shorts/i32GX4bEYwo)
