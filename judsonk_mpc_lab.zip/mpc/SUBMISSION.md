# Lab 6: SLAM and Pure Pursuit

## YouTube video link
[MPC Sim Demo](https://youtu.be/-7YGVw7MrBM)
