# Lab 2: Automatic Emergency Braking

## YouTube video link
[FILL ME IN](https://youtu.be/vfiBSon6uyg)