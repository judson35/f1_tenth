# Lab 4: Follow the Gap

## YouTube video link
Levine Blocked (https://youtu.be/8xtltXXu7mE)
Levine Obs (https://youtu.be/J4sNyP_iu0E)
 - can't make the whole course because it get's confused about the gap to the right of the blocks and thinks that's the best course foward but doesn't have any mechanism to tell whether it can fit through the gap it's trying to go towards.
Gap Follow Hardware (https://youtube.com/shorts/HiWwP1WgXB8)